class Node(object):
    def __init__(self, data, next=None, prev=None):
        self.data = data
        self.next = next
        self.prev = prev

def cari(head, yang_dicari):
    curNode = head
    data = False

    while curNode is not None:
        if curNode.data.lower() == yang_dicari.lower():
            data = True
            break
        else:
            curNode = curNode.next
    
    return data

a = Node("Arga")
b = Node("Bryan")
c = Node("Mukhti")
d = Node("Alip")
e = Node("Hudi")
x = Node("Budi")

a.next = b 
b.next = c
c.next = d
d.next = e

print("===========Mencari data========")
dataCari = str(input("Data yang ingin dicari: "))
if cari(a, dataCari) == True:
    print("Data "+dataCari+" ditemukan")
else:
    print("Data "+dataCari+" tidak ada dalam memory")