class DNode(object):
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

def tambahDepan(head, data):
    curHead = head

    data.next = curHead
    curHead = data

    curHead.prev = data
    data = curHead

    while curHead is not None:
        print(curHead.data)
        curHead = curHead.next

a = DNode("Arga")
b = DNode("Bryan")
c = DNode("Nopal")
d = DNode("Mukhti")
e = DNode("Hudi")
x = DNode("Ilyah")

a.next = b
b.prev = a
b.next = c
c.prev = b
c.next = d
d.prev = c
d.next = e

print("======Menambah Simpul di awal========")
tambahDepan(a, x)