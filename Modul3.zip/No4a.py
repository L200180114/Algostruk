class DNode(object):
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

def cetakMaju(head):
    curHead = head

    while curHead is not None:
        print(curHead.data)
        curHead = curHead.next

def cetakMundur(tail):
    curTail = tail

    while curTail is not None:
        print(curTail.data)
        curTail = curTail.prev

a = DNode("Arga")
b = DNode("Bryan")
c = DNode("Nopal")
d = DNode("Mukhti")
e = DNode("Hudi")
x = DNode("Ilyah")

a.next = b
b.prev = a 
b.next = c
c.prev = b
c.next = d
d.prev = c
d.next = e
e.prev = d

print("======Mencetak Maju======")
cetakMaju(a)

print("\n=====Mencetak Mundur====")
cetakMundur(e)