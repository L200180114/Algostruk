def buatNol(m, n=None):
    if n == None:
        n = m 

    matrix = [[0 for j in range(n)] for i in range(m)]

    for x in range(len(matrix)):
        for y in range(len(matrix)):
            print(matrix[x][y], end=" ")
        print()

def buatIdentitas(m):
    matrix = [[1 if j == i else 0 for j in range(m)] for i in range(m)]

    for x in range(len(matrix)):
        for y in range(len(matrix)):
            print(matrix[x][y], end=" ")
        print()

print("#####Matrix berisi nol########")
a = int(input("Masukkan jumlah ordo: "))
buatNol(a)

print("\n#####Matrix Indentitas#######")
b = int(input("Masukkan jumlah ordo: "))
buatIdentitas(b)