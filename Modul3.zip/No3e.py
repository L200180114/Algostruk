class Node(object):
    def __init__(self, data, next=None, prev=None):
        self.data = data
        self.next = next
        self.prev = prev

def hapus(head, data):
    curHead = head

    while curHead is not None:
        if curHead.data == data.data:
            curHead = data.next
            print(curHead.data)
            curHead = curHead.next
        else:
            print(curHead.data)
            curHead = curHead.next

a = Node("Arga")
b = Node("Bryan")
c = Node("Mukhti")
d = Node("Alip")
e = Node("Hudi")
x = Node("Budi")

a.next = b 
b.next = c
c.next = d
d.next = e

print("===========Menghapus Data========")
hapus(a, b)