class DNode(object):
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

def tambahAkhir(head, data):
    curHead = head

    while curHead is not None:
        print(curHead.data)
        curHead = curHead.next

    data.prev = curHead
    curHead = data

    print(curHead.data)

a = DNode("Arga")
b = DNode("Bryan")
c = DNode("Nopal")
d = DNode("Mukhti")
e = DNode("Hudi")
x = DNode("Ilyah")

a.next = b
b.prev = a
b.next = c
c.prev = b
c.next = d
d.prev = c
d.next = e

print("======Menambah Simpul di akhir========")
tambahAkhir(a, x)