class Node(object):
    def __init__(self, data, next=None, prev=None):
        self.data = data
        self.next = next
        self.prev = prev

def tambah(head, data, posisi):
    curHead = head

    data.next = posisi.next
    posisi.next = data

    while curHead is not None:
        print(curHead.data)
        curHead = curHead.next

a = Node("Arga")
b = Node("Bryan")
c = Node("Mukhti")
d = Node("Alip")
e = Node("Hudi")
x = Node("Budi")

a.next = b 
b.next = c
c.next = d
d.next = e

print("==========Menyisipkan Simpul di Mana Aja========")
tambah(a, x, b)