def determinanMatrix(matrix):
    if len(matrix) != len(matrix[0]):
        print('Matriks harus bujur sangkar')
        return

    tambah = [1 for i in range(len(matrix))]
    kurang = [1 for i in range(len(matrix))]

    for i in range(len(matrix)):
        for j in range(len(matrix) - 1):
            matrix[i].append(matrix[i][j])

    matrix2 = matrix.copy()

    for i in range(len(matrix2)):
        matrix2[i] = list(reversed(matrix2[i]))

    nilai = 0
    for i in range(len(matrix)):
        for j in range(len(matrix)):
            tambah[i] *= matrix[j][j + nilai]
            kurang[i] *= matrix2[j][j + nilai]
        nilai += 1

    kurang = [-x for x in kurang]
    determinan = sum(tambah) + sum(kurang)

    return determinan

# a = [[2,3,4], [3,4,3], [4,3,4]]
# print(determinanMatrix(a))