import sys
from No1Der import determinanMatrix

matriks1 = []
matriks2 = []

huruf = "ABCDEFGHIJKLMNOPQRSTUVWXYSabcdefghijklmnopqrstuvwxyz"

print("#########Import Matriks ke 1############")
a = int(input("Matriks ordo: "))
for i in range(a):
    inputMatriks = input("Masukkan nilai matriks ke-"+str(i+1)+": ")
    matriksplit = inputMatriks.split(",")
    list = []
    for x in matriksplit:
        if "." in x:
            list.append(float(x))
        elif x == "True" or x == "False":
            list.append(bool(x))
        elif x in huruf:
            list.append(str(x))
        else:
            list.append(int(x))
    matriks1.append(list)

print("########Import Matriks ke 2##########")
b = int(input("Matriks ordo: "))
for i in range(b):
    inputMatriks = input("Masukkan nilai matriks ke-"+str(i+1)+": ")
    matriksplit = inputMatriks.split(",")
    list = []
    for x in matriksplit:
        if "." in x:
            list.append(float(x))
        elif x == "True" or x == "False":
            list.append(bool(x))
        elif x in huruf:
            list.append(str(x))
        else:
            list.append(int(x))
    matriks2.append(list)

print("\n########Check Matriks#######")
def checkMatriks(input):
    hasil = True
    for i in input:
        if len(input) != len(i):
            hasil = False
            break

        for x in i :
            if type(x) == str or type(x) == bool:
                hasil = False
            break
    return hasil

if checkMatriks(matriks1) == False or checkMatriks(matriks2) == False:
    print("Salah satu matriks tidak berbentuk bunjur sangkar atau terdapat nilai selain angka")
    sys.exit(" ")
else:
    print("Matriks berbentuk bunjur sangkar")

print("\n##########Mengambil ukuran matriks############")
def ambilMatriks(input):
    for x in range(len(input)):
        for y in range(len(input[0])):
            print(input[x][y], end=" ")
        print()
print("Matriks 1")
ambilMatriks(matriks1)
print("\nMatriks 2")
ambilMatriks(matriks2)

print("\n##########Menjumlahkan dua Matriks############")
if a != b:
    print("Matriks 1 dan Matriks 2 tidak sesuai")
    sys.exit(" ")
else:
    for x in range(0, len(matriks1[0])):
        for y in range(0, len(matriks1[0])):
            c = matriks1[x][y] + matriks2[x][y]
            print(c, end=" ")
        print()

print("\n#########Mengalikan dua Matriks##############")
nilai = []
nilai2 = []
nilai_sum = 0
if a != b:
    print("Matriks 1 dan Matriks 2 tidak sesuai")
    sys.exit(" ")
else:
    for i in range(len(matriks1)):
        for x in range(len(matriks1[0])):
            for y in range(len(matriks1)):
                nilai_sum += matriks1[i][y] * matriks2[x][y]
            nilai2.append(nilai_sum)
            nilai_sum = 0
        nilai.append(nilai2)
        nilai2 = []

for x in range(len(nilai)):
    for y in range(len(nilai)):
        print(nilai[x][y], end=" ")
    print()

print("\n##########Determinan Matriks#################")
print(determinanMatrix(matriks1))