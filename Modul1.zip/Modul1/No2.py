def gambarlahPersegiEmpat(x, b):
    a = "@"
    print(a * b)
    f = x - 2
    c = b - 4
    for e in range(f):
        print(a, " "*c, a)
    print(a * b)

    
gambarlahPersegiEmpat(5, 10)