def apakahTerkandung(x, y):
    if x in y:
        print(True)
    else:
        print(False)

h = "do"
k = "Indonesia tanah air beta"
apakahTerkandung("Pusaka", k)