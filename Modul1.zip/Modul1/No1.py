def cetakSiku(input):
    x = 1 + input
    for i in range(x):
        a = "*"
        b = i * a
        print(b)

cetakSiku(5)
