def ucapkanSalam():
    print("Assalamu 'alaikum!")

def kuadratkan(x):
    return x*x 

buah = "Mangga"
daftarBaju = ['batik', 'loreng', 'resmi berdasi']
jumlahBaju = len(daftarBaju)