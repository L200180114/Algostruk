def insertSort(A, B):
    C.extend(A+B)
    n = len(C)
    for i in range(1, n):
        nilai = C[i]
        pos = i
        while pos > 0 and nilai < C[pos - 1]:
            C[pos] = C[pos-1]
            pos -= 1
        C[pos] = nilai

A = [1,3,5,7,9,13,34,54]
B = [2,4,6,8,12,35]
C = []
insertSort(A, B)
print(C)
